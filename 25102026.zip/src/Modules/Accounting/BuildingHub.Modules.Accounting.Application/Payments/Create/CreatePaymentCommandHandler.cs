﻿
using BuildingHub.Modules.Accounting.Application.Abstractions;
using BuildingHub.Modules.Accounting.Domain.Entities;
using MediatR;

namespace BuildingHub.Modules.Accounting.Application.Payments.Create;

public sealed class CreatePaymentCommandHandler
    : IRequestHandler<CreatePaymentCommand, Guid>
{
    private readonly IPaymentRepository _paymentRepository;
    private readonly IUnitChargeRepository _unitChargeRepository;

    public CreatePaymentCommandHandler(
        IPaymentRepository paymentRepository,
        IUnitChargeRepository unitChargeRepository)
    {
        _paymentRepository = paymentRepository;
        _unitChargeRepository = unitChargeRepository;
    }

    public async Task<Guid> Handle(
        CreatePaymentCommand request,
        CancellationToken cancellationToken)
    {
        if (request.UnitChargeId == Guid.Empty)
        {
            throw new ArgumentException(
                "UnitChargeId is required.");
        }

        if (request.Amount <= 0)
        {
            throw new ArgumentException(
                "Payment amount must be greater than zero.");
        }

        var unitCharge = await _unitChargeRepository.GetByIdAsync(
            request.UnitChargeId,
            cancellationToken);

        if (unitCharge is null)
        {
            throw new InvalidOperationException(
                "Unit charge was not found.");
        }

        var existingPayments =
            await _paymentRepository.GetByUnitChargeIdAsync(
                request.UnitChargeId,
                cancellationToken);

        var paidAmount = existingPayments.Sum(
            payment => payment.Amount);

        var remainingAmount = unitCharge.Amount - paidAmount;

        if (remainingAmount <= 0)
        {
            throw new InvalidOperationException(
                "This unit charge has already been fully paid.");
        }

        if (request.Amount > remainingAmount)
        {
            throw new InvalidOperationException(
                $"Payment amount exceeds the remaining balance of {remainingAmount}.");
        }

        var payment = Payment.Create(
            request.UnitChargeId,
            request.Amount,
            request.PaidAt,
            request.TrackingNumber);

        await _paymentRepository.AddAsync(
            payment,
            cancellationToken);

        return payment.Id;
    }
}
