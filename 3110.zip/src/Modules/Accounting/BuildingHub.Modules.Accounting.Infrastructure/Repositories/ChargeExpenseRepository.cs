﻿
using BuildingHub.Modules.Accounting.Application.Abstractions;
using BuildingHub.Modules.Accounting.Domain.Entities;
using BuildingHub.Modules.Accounting.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace BuildingHub.Modules.Accounting.Infrastructure.Repositories;

public sealed class ChargeExpenseRepository
    : Repository<ChargeExpense>, IChargeExpenseRepository
{
    public ChargeExpenseRepository(AccountingDbContext context)
        : base(context)
    {
    }

    public async Task<decimal> GetTotalAllocatedAmountByExpenseIdAsync(
        Guid expenseId,
        CancellationToken cancellationToken = default)
    {
        return await Context.ChargeExpenses
            .Where(x => x.ExpenseId == expenseId)
            .SumAsync(
                x => (decimal?)x.AllocatedAmount,
                cancellationToken) ?? 0m;
    }

    public async Task<bool> ExistsAsync(
        Guid expenseId,
        Guid chargeId,
        CancellationToken cancellationToken = default)
    {
        return await Context.ChargeExpenses
            .AnyAsync(
                x => x.ExpenseId == expenseId &&
                     x.ChargeId == chargeId,
                cancellationToken);
    }
}
