﻿
using BuildingHub.Modules.Accounting.Domain.Entities;

namespace BuildingHub.Modules.Accounting.Application.Abstractions;

public interface IPaymentRepository : IRepository<Payment>
{
    Task<IReadOnlyList<Payment>> GetByUnitChargeIdAsync(
        Guid unitChargeId,
        CancellationToken cancellationToken = default);
}
