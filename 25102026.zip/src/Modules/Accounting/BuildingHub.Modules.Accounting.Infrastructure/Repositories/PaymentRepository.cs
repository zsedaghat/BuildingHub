﻿
using BuildingHub.Modules.Accounting.Application.Abstractions;
using BuildingHub.Modules.Accounting.Domain.Entities;
using BuildingHub.Modules.Accounting.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;

namespace BuildingHub.Modules.Accounting.Infrastructure.Persistence;

public sealed class PaymentRepository : Repository<Payment>, IPaymentRepository
{
    public PaymentRepository(AccountingDbContext context)
        : base(context)
    {
    }

    public async Task<IReadOnlyList<Payment>> GetByUnitChargeIdAsync(
        Guid unitChargeId,
        CancellationToken cancellationToken = default)
    {
        return await Context.Set<Payment>()
            .AsNoTracking()
            .Where(payment => payment.UnitChargeId == unitChargeId)
            .ToListAsync(cancellationToken);
    }
}
