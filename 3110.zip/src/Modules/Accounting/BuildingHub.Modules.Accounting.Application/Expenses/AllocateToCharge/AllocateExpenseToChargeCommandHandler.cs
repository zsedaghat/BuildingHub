﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildingHub.Modules.Accounting.Application.Expenses.AllocateToCharge
{
    internal class AllocateExpenseToChargeCommandHandler
    {
    }
}
