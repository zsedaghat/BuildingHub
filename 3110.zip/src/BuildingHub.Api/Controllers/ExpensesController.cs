﻿
using BuildingHub.Modules.Accounting.Application.Expenses.Create;
using BuildingHub.Modules.Accounting.Application.Expenses.GetByBuilding;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace BuildingHub.Api.Controllers;

[ApiController]
[Route("api/buildings/{buildingId:guid}/expenses")]
public sealed class ExpensesController : ControllerBase
{
    private readonly ISender _sender;

    public ExpensesController(ISender sender)
    {
        _sender = sender;
    }

    [HttpPost]
    public async Task<IActionResult> Create(
        Guid buildingId,
        [FromBody] CreateExpenseRequest request,
        CancellationToken cancellationToken)
    {
        var command = new CreateExpenseCommand(
            buildingId,
            request.Title,
            request.Amount,
            request.ExpenseDate,
            request.Description);

        var expenseId = await _sender.Send(
            command,
            cancellationToken);

        return Created(
            $"/api/buildings/{buildingId}/expenses/{expenseId}",
            new { id = expenseId });
    }



    [HttpGet]
    public async Task<IActionResult> GetByBuilding(
        Guid buildingId,
        CancellationToken cancellationToken)
    {
        var query = new GetExpensesByBuildingQuery(buildingId);

        var expenses = await _sender.Send(
            query,
            cancellationToken);

        return Ok(expenses);
    }


}

public sealed record CreateExpenseRequest(
    string Title,
    decimal Amount,
    DateOnly ExpenseDate,
    string? Description);
