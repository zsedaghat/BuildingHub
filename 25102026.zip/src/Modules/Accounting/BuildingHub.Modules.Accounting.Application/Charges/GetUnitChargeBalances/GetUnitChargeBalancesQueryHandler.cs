﻿
using BuildingHub.Modules.Accounting.Application.Abstractions;
using MediatR;

namespace BuildingHub.Modules.Accounting.Application.Charges.GetUnitChargeBalances;

public sealed class GetUnitChargeBalancesQueryHandler
    : IRequestHandler<GetUnitChargeBalancesQuery, IReadOnlyList<UnitChargeBalanceDto>>
{
    private readonly IUnitChargeRepository _unitChargeRepository;
    private readonly IPaymentRepository _paymentRepository;
    private readonly IBuildingUnitProvider _unitProvider;

    public GetUnitChargeBalancesQueryHandler(
        IUnitChargeRepository unitChargeRepository,
        IPaymentRepository paymentRepository,
        IBuildingUnitProvider unitProvider)
    {
        _unitChargeRepository = unitChargeRepository;
        _paymentRepository = paymentRepository;
        _unitProvider = unitProvider;
    }

    public async Task<IReadOnlyList<UnitChargeBalanceDto>> Handle(
        GetUnitChargeBalancesQuery request,
        CancellationToken cancellationToken)
    {
        if (request.BuildingId == Guid.Empty ||
            request.ChargeId == Guid.Empty)
        {
            throw new ArgumentException(
                "BuildingId and ChargeId are required.");
        }

        var unitCharges = await _unitChargeRepository.GetByChargeIdAsync(
            request.ChargeId,
            cancellationToken);

        var units = await _unitProvider.GetActiveUnitsAsync(
            request.BuildingId,
            cancellationToken);

        var unitsById = units.ToDictionary(x => x.UnitId);

        var result = new List<UnitChargeBalanceDto>();

        foreach (var unitCharge in unitCharges)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var payments = await _paymentRepository.GetByUnitChargeIdAsync(
                unitCharge.Id,
                cancellationToken);

            var paidAmount = payments.Sum(payment => payment.Amount);

            var unitNumber = unitsById.TryGetValue(
                unitCharge.UnitId,
                out var unit)
                ? unit.UnitNumber
                : "واحد غیرفعال یا یافت‌نشده";

            result.Add(new UnitChargeBalanceDto(
                unitCharge.Id,
                unitCharge.UnitId,
                unitNumber,
                unitCharge.Amount,
                paidAmount,
                unitCharge.Amount - paidAmount));
        }

        return result;
    }
}
